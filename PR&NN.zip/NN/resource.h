//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NN.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NNTYPE                      129
#define IDD_DIALOG_XOR                  130
#define IDD_DIALOG_BPNN                 131
#define IDD_DIALOG_HOPFIELD             132
#define IDC_EDIT_X                      1000
#define IDC_EDIT_Y                      1001
#define IDC_EDIT_RESULT                 1002
#define IDC_DRAW                        1011
#define IDC_BUTTON_INITIAL              1012
#define IDC_EDIT_TRAIN00                1013
#define IDC_EDIT_TRAIN01                1014
#define IDC_EDIT_TEST0                  1015
#define IDC_EDIT_TEST1                  1016
#define IDC_MEMORY                      1017
#define IDC_EDIT_TRAIN02                1018
#define IDC_EDIT_TRAIN10                1019
#define IDC_EDIT_TRAIN11                1020
#define IDC_EDIT_TRAIN12                1021
#define IDC_EDIT_TRAIN20                1022
#define IDC_EDIT_TRAIN21                1023
#define IDC_EDIT_TRAIN22                1024
#define IDC_EDIT_TEST2                  1025
#define IDC_EDIT_RESULT0                1026
#define IDC_EDIT_ITER                   1026
#define IDC_EDIT_RESULT1                1027
#define IDC_EDIT_ERROR                  1027
#define IDC_EDIT_RESULT2                1028
#define IDC_BUTTON_ERROR                1028
#define ID_XOR                          32771
#define ID_NONLINEAR                    32772
#define ID_AUTO_CLUSTER                 32773
#define ID_ASSOCIATE_MEMORY             32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
