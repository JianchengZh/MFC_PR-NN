//nrttil.h
//���ڶ�̬���������

#ifndef _nrutil_h_
#define _nrutil_h_

void nrerror(char *error_text);
float *vector(long nl,long nh);
int *ivector(long nl,long nh);
unsigned char *cvector(long nl,long nh);
unsigned long *lvector(long nl,long nh);
double *dvector(long nl,long nh);
float **matrix(long nrl,long nrh,long ncl,long nch);
double **dmatrix(long nrl,long nrh,long ncl,long nch);
int **imatrix(long nrl,long nrh,long ncl,long nch);
unsigned char **cmatrix(long nrl,long nrh,long ncl,long nch);
float **submatrix(float **a,long oldrl,long oldrh,long oldcl,long oldch,long newrl,long newcl);
float **convert_matrix(float *a,long nrl,long nrh,long ncl,long nch);
float ***f3tensor(long nrl,long nrh,long ncl,long nch,long ndl,long ndh);
void free_vector(float *v,long nl,long nh);
void free_ivector(int *v,long nl,long nh);
void free_cvector(unsigned char *v,long nl,long nh);
void free_lvector(unsigned long *v,long nl,long nh);
void free_dvector(double *v,long nl,long nh);
void free_matrix(float **m,long nrl,long nrh,long ncl,long nch);
void free_dmatrix(double **m,long nrl,long nrh,long ncl,long nch);
void free_imatrix(int **m,long nrl,long nrh,long ncl,long nch);
void free_cmatrix(unsigned char **m,long nrl,long nrh,long ncl,long nch);
void free_submatrix(float **b,long nrl,long nrh,long ncl,long nch);
void free_convert_matrix(float **b,long nrl,long nrh,long ncl,long nch);

#endif //_nrutil_h_
