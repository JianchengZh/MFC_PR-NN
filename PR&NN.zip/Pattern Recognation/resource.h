//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pattern Recognation.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PATTERTYPE                  129
#define IDD_DIALOG_TEXTURE_GRAYSHOW     130
#define IDD_DIALOG_LINEAR_FISHER        132
#define IDD_DIALOG_NONLINEAR            133
#define IDD_DIALOG_CLUSTER              134
#define IDD_DIALOG_FUZZY                135
#define IDC_EDIT_ENERGY                 1001
#define IDC_EDIT_ENTROPY                1002
#define IDC_EDIT_INERTIA_QUADRATURE     1003
#define IDC_EDIT_LOCAL_CALM             1005
#define IDC_EDIT_CORRELATION            1006
#define IDC_BUTTON_PERCEPTRON           1006
#define IDC_BUTTON_FISHER               1008
#define IDC_COORD1                      1009
#define IDC_BUTTON_NEAREST              1010
#define IDC_BUTTON_K_NEAREST            1011
#define IDC_CORAD_NON                   1012
#define IDC_BUTTON_C_MEANS              1013
#define IDC_BUTTON_ISODATA              1014
#define IDC_EDIT_I                      1015
#define IDC_EDIT_ERRORX_ADD             1016
#define IDC_DRAW_CLUSTER                1017
#define IDC_EDIT_Cval                   1018
#define IDC_EDIT_C                      1018
#define IDC_EDIT_Jval                   1019
#define IDC_DRAW_FUZZY                  1020
#define IDC_EDIT_k                      1021
#define IDC_EDIT_thetaN                 1022
#define IDC_EDIT_thetaS                 1023
#define IDC_EDIT_thetaD                 1024
#define ID_LINEAR_FISHER_DISCRIMINTIVE  32772
#define ID_NONLINEAR                    32774
#define ID_FUZZY_CLUSTER_C_MEANS        32778
#define ID_FEATUREEXTRACT_TEXTURE       32779
#define ID_CLUSTER_ANALYSIS             32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
